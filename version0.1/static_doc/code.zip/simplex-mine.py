import numpy as np

objs=[0] #存放最终目标值
#读取pj，也就是每个变量对应的约束矩阵的系数，pj是一个个列向量组成的
def getPj(d):
    (bn, cn) = d.shape
    pj1 = d[1:bn,:]
    pj =  pj1[:,0:cn-1]
    return pj

def loadData():
    d = np.loadtxt("simplexdata2.txt", dtype=np.float)
    (bn, cn) = d.shape
    #读入的第一行是目标函数，余下的行是约束
    cost=d[0]
    constraints = d[1:bn,:]
    #取得pj
    pj=getPj(d)
    basicList = list(range(cn - bn , cn - 1))  # 基变量列表
    return basicList,pj,constraints,cost,cn

#计算判别数
def evaluateValues(cn,constraints):
    cbList=[]
    zjcj=[]
    for i in range(len(basicList)):
        xbi=basicList[i]
        cbi=cost[xbi]
        cbList.append(cbi)
    CB = np.array(cbList)

    for j in range(cn - 1): #每个变量，计算zj-cj
        pjj = pj[:,j] #取出第j的pj
        pjt = pjj.reshape(len(pjj), 1) #转置
        zj=np.dot(CB,pjt)
        cj=cost[j]
        zjcj.append(zj-cj)
    return zjcj,CB

#单纯性方法的最核心的代码，
#     1. 首先找到换入变量对应的列的编号，
#     2. 之后找到换出变量的行，
#     3.然后矩阵初等变换后，
#     4.调整基变量列表，进行下一次迭代
def pivot(zjcj,CB,constraints):
    jnum = zjcj.index(max(zjcj))  # 换入变量的编号
    m = []
    constraintNumber = constraints.shape[0]   #约束数量，即m
    for i in range(constraintNumber):    #循环计算 bi/aij，找到最小值，即换出行号
        if constraints[i][jnum] == 0:
            m.append(0.)
        else:
            m.append(constraints[i][-1] / constraints[i][jnum])
    inum = m.index(min([x for x in m[1:] if x >= 0]))  # 换出行号
    '''
    print(zjcj)
    print(jnum)
    inum=0
    min_value=1000000
    for kk in range(len(m)):
        value=m[kk]
        print(value)
        if value>=0 and value<min_value:
            min_value=value
            inum=kk
    print(min_value)
    '''
    basicList[inum ] = jnum  #替换，basicList即对应单纯性表的最左边一列，基变量列表
    r = constraints[inum][jnum] #pivot的数值，用于初等变换
    constraints[inum] /= r      #初等变换第一步，pivot这一行调整
    for i in [x for x in range(constraintNumber) if x != inum]:
        r = constraints[i][jnum]
        constraints[i] -= r * constraints[inum]  #其余行全部调整
    current_b = constraints[:,cn-1]  #当前的b
    #计算current CB
    zjcj,CB = evaluateValues(cn,constraints)
    obj=np.dot(CB,current_b)
    objs.append(obj)
    #------打印约束矩阵，判别数信息
    zjcj2=np.array(zjcj)
    zhcj3=zjcj2.reshape(1,len(zjcj2))
    print(constraints)
    print(zhcj3) #转置
    print("------------------------------------------------------")
    return constraints,objs

def solve(cn,constraints):
    flag = True
    while flag:
        zjcj, CB = evaluateValues(cn,constraints)  # 计算每个变量的最后一行，即判别数
        if max(list(zjcj)) <= 0:  #如果判别数全部不满足，即没有>0的数，则退出
            flag = False
        else:
            constraints,objs = pivot(zjcj,CB,constraints)      #如果可以继续，则调用pivot函数，换入换出一对变量

def printSol():
    print("最后在基变量中的变量编号，注意这里编号从0开始：",basicList)
    print("基本变量：", "\t")
    for i in range(cn - 1):
        if i in basicList:
            print("x" + str(i+1) + "=%.2f" % constraints[basicList.index(i) ][-1],"\t",end=' ')
        '''
        else:
            print("非基本变量：","\t",end=' ')
            print("x" + str(i+1) + "=0.00")
        '''
    print()
    print("======================================================")
    print("objective is %.2f" % (objs[len(objs)-1]))
    print(objs)

#------------------------------------------------------------  主程序开始
#step1, basicList表示基变量的编号集合；pj表示变量的约束矩阵的系数列向量；constraints是约束矩阵，cost是目标函数系数向量
basicList, pj ,constraints, cost,cn = loadData()
#step2. 开始计算
solve(cn,constraints)
printSol()
